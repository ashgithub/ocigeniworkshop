import oci
import oracledb
import sys 

print ("hello AI workshop")
print(f"python version: {sys.version}")
print(f"oci sdk version: {oci.version.__version__}")
print(f"oraceldb client sdk version: {oracledb.version}")

