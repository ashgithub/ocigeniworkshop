#https://github.com/oracle/oci-python-sdk/tree/22fd62c8dbbd1aaed6b75754ec1ba8a3c16a4e5a/src/oci/ai_vision
#https://docs.oracle.com/en-us/iaas/Content/vision/using/home.htm

import oci
import io
import uuid
from oci.object_storage import ObjectStorageClient

CONFIG_PROFILE = "ASAGARWA-WORKSHOP"
PREFIX = "AAGARWA" # ********* CHANGE ME ************

config = oci.config.from_file('~/.oci/config', CONFIG_PROFILE)

COMPARTMENT_ID = "ocid1.compartment.oc1..aaaaaaaa5wmdeu3rf5s4rs4l66rksphne2orz4buauniiqtar63du6ni7icq" 
NAMESPACE = "axaemuxiyife"
BUCKET_NAME = "workshopbucket"
FILE_PATH = "reciept.png"
FILE_NAME ="reciept.png"


def upload(file_path):
    object_storage_client = ObjectStorageClient(config)
    print(f"Uploading file {file_path} ...")
    object_storage_client.put_object(NAMESPACE, BUCKET_NAME, FILE_NAME, io.open(file_path,'rb'))
    print("Upload completed !")


def get_imag_location(file_name): 
    image = oci.ai_vision.models.ObjectStorageImageDetails(
                            source = "OBJECT_STORAGE",
                            namespace_name = NAMESPACE,
                            bucket_name=BUCKET_NAME,
                            object_name=file_name
    )

    return image

def get_details(features, file_name) :
    details = oci.ai_vision.models.AnalyzeImageDetails(
        
        features = features,
        image = get_imag_location(file_name),
        compartment_id=COMPARTMENT_ID
    )

    return details


#upload(FILE_PATH)
vision_client = oci.ai_vision.AIServiceVisionClient(config=config)

features = [ 
#            oci.ai_vision.models.ImageClassificationFeature(),
#            oci.ai_vision.models.ImageObjectDetectionFeature(),
            oci.ai_vision.models.ImageTextDetectionFeature(),
#            oci.ai_vision.models.FaceDetectionFeature()
           ]

response = vision_client.analyze_image ( get_details (features, FILE_NAME))

print(response.data)