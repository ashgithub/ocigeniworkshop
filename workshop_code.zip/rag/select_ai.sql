

--https://docs.oracle.com/en-us/iaas/autonomous-database-serverless/doc/select-ai-examples.html#GUID-2FBD7DDB-CAC3-47AF-AB66-17F44C2ADAA4


BEGIN
dbms_cloud_ai.drop_profile(
    profile_name => 'genaish',
    force => true
    );
END;
/

BEGIN
DBMS_CLOUD_AI.CREATE_PROFILE (
        profile_name => 'genaish',        
        attributes => '{
            "provider": "oci",
             "credential_name": "OCI_GENAI_CRED",
            "model":"meta.llama-3.1-70b-instruct",
            "comments":"true",            
            "object_list": [{"owner": "SH"}]
            }'
        );
end;
/

begin
  dbms_cloud_ai.set_profile(
        profile_name => 'genaish'
    );
end;
/

set wrap on


select ai how many customers exist;
select ai runsql  narrate how many customers exist;
select ai showsql  narrate how many customers exist;
select ai explainsql  narrate how many customers exist;
select ai narrate how many customers exist;
select ai chat how many customers exist;
select ai chat why is sky blue
select ai explainsql how many customers in San Francisco are married;

select ai find top3 baby boomer big spenders
select ai showsql find top3 baby boomer big spenders